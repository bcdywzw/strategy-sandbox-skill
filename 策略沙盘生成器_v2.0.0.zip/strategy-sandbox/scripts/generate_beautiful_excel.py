#!/usr/bin/env python3
"""
策略沙盘Excel生成脚本 v4.0（双模板版）
支持：串联模板(8行) + 并联模板(11行) + 自定义模板

用法：
  python3 generate_beautiful_excel.py --template [series|parallel|custom] --data data.json --output out.xlsx

  --template series    → 串联模板（总业绩→人力→触客→转化→客均件数→件均单价→心态，8行）
  --template parallel  → 并联模板（老客板块+新客板块+人效板块，11行）
  --template custom    → 自定义模板（沿用串联模板逻辑）
"""

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
import json
import argparse

# ============ 颜色 ============
YELLOW_FILL  = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
WHITE_FILL   = PatternFill(start_color="FFFFFF", end_color="FFFFFF", fill_type="solid")
# 并联模板各板块颜色（用与theme相近的RGB近似色）
OLDCLIENT_FILL = PatternFill(start_color="E8EAF6", end_color="E8EAF6", fill_type="solid")  # 浅紫蓝-老客
NEWCLIENT_FILL = PatternFill(start_color="E3F2FD", end_color="E3F2FD", fill_type="solid")  # 浅蓝-新客
PERF_FILL     = PatternFill(start_color="E8F5E9", end_color="E8F5E9", fill_type="solid")  # 浅绿-人效

# 串联：仅A列+第1行黄色，其他白色
# 并联：第1行黄色，各板块分区着色

# ============ 边框 ============
def thick_border():
    s = Side(style='medium', color='000000')
    return Border(left=s, right=s, top=s, bottom=s)

# ============ 固定标签 ============
# 串联模板
SERIES_TEMPLATE = {
    1: {"A": "维度",      "B": "去年完成(R)", "C": "今年目标(O)", "D": "行动策略(KR)", "E": "可衡量结果(KR)", "F": "负责人(O)", "G": "截止日(D)"},
    2: {"A": "总业绩"},
    3: {"A": "业务总人力"},
    4: {"A": "人均触客数"},
    5: {"A": "转化率"},
    6: {"A": "客均件数"},
    7: {"A": "件均单价"},
    8: {"A": "心态"},
}
SERIES_ROWS = 8

# 并联模板
PARALLEL_TEMPLATE = {
    1:  {"A": "维度",      "B": "去年完成", "C": "今年目标", "D": "行动策略", "E": "可衡量结果", "F": "负责人", "G": "截止日"},
    2:  {"A": "老客业绩"},
    3:  {"A": "老客户数"},
    4:  {"A": "续签率"},
    5:  {"A": "老客均价"},
    6:  {"A": "新客业绩"},
    7:  {"A": "新客户数"},
    8:  {"A": "转化率"},
    9:  {"A": "新客均价"},
    10: {"A": "人数"},
    11: {"A": "人效"},
}
PARALLEL_ROWS = 11

# 并联模板：各板块颜色
PARALLEL_FILLS = {
    1: YELLOW_FILL,      # 表头
    2: OLDCLIENT_FILL,    # 老客业绩
    3: OLDCLIENT_FILL,    # 老客户数
    4: OLDCLIENT_FILL,    # 续签率
    5: OLDCLIENT_FILL,    # 老客均价
    6: NEWCLIENT_FILL,    # 新客业绩
    7: NEWCLIENT_FILL,    # 新客户数
    8: NEWCLIENT_FILL,    # 转化率
    9: NEWCLIENT_FILL,    # 新客均价
    10: PERF_FILL,       # 人数
    11: PERF_FILL,       # 人效
}

# 并联模板：列宽配置（7列）
PARALLEL_COL_WIDTHS = {'A': 12, 'B': 22, 'C': 22, 'D': 55, 'E': 40, 'F': 12, 'G': 12}
# 串联模板：列宽配置
SERIES_COL_WIDTHS = {'A': 12, 'B': 22, 'C': 28, 'D': 55, 'E': 40, 'F': 14, 'G': 14}


def text_width(text):
    if not text:
        return 0
    return sum(2 if ord(ch) > 127 else 1 for ch in str(text))


def calc_lines(text, col_width_ch):
    if not text or col_width_ch <= 0:
        return 1
    raw_lines = str(text).split('\n')
    total = 0
    for line in raw_lines:
        line_w = text_width(line)
        if line_w == 0:
            total += 1
        else:
            wrapped = (line_w + col_width_ch - 1) // col_width_ch
            total += max(1, wrapped)
    return max(1, total)


def set_cell(ws, coord, value, fill, bold=False, size=10):
    cell = ws[coord]
    cell.value = value if value is not None else "?"
    cell.fill = fill
    cell.alignment = Alignment(wrap_text=True, vertical='center', horizontal='left')
    cell.border = thick_border()
    cell.font = Font(bold=bold, size=size)


def fill_series_sheet(ws, data):
    """填充串联模板（8行×7列）"""
    ws.row_dimensions[1].height = 35
    col_widths = SERIES_COL_WIDTHS

    for row_num in range(1, SERIES_ROWS + 1):
        template_row = SERIES_TEMPLATE.get(row_num, {})

        # 第1行：表头
        if row_num == 1:
            ws.row_dimensions[1].height = 35
            for col, text in template_row.items():
                set_cell(ws, f"{col}1", text, fill=YELLOW_FILL, bold=True, size=11)
        else:
            # 维度标签列（黄色）
            dim_text = template_row.get("A", "")
            ws.row_dimensions[row_num].height = 35
            set_cell(ws, f"A{row_num}", dim_text, fill=YELLOW_FILL, bold=True, size=11)

            # 数据列
            field_map = {
                "B": "去年", "C": "今年", "D": "策略",
                "E": "可衡量", "F": "负责人", "G": "截止日"
            }
            for col, key in field_map.items():
                val = data.get(dim_text, {}).get(key, "?") if dim_text else "?"
                is_num_col = col in ('B', 'C')
                set_cell(ws, f"{col}{row_num}", val,
                         fill=WHITE_FILL, bold=False, size=10)

    # 设置列宽
    for col, width in col_widths.items():
        ws.column_dimensions[col].width = width

    # 自动行高（根据D列内容行数）
    for row_num in range(2, SERIES_ROWS + 1):
        dim_text = SERIES_TEMPLATE[row_num].get("A", "")
        strategy_text = data.get(dim_text, {}).get("策略", "?") if dim_text else "?"
        lines = calc_lines(strategy_text, col_widths['D'])
        ws.row_dimensions[row_num].height = max(30, lines * 18 + 10)

    ws.freeze_panes = 'B2'


def fill_parallel_sheet(ws, data):
    """填充并联模板（11行×7列）"""
    col_widths = PARALLEL_COL_WIDTHS

    for row_num in range(1, PARALLEL_ROWS + 1):
        template_row = PARALLEL_TEMPLATE.get(row_num, {})
        fill = PARALLEL_FILLS.get(row_num, WHITE_FILL)
        is_header = (row_num == 1)

        ws.row_dimensions[row_num].height = 35 if is_header else 35

        # A列
        set_cell(ws, f"A{row_num}", template_row.get("A", ""),
                 fill=fill, bold=is_header, size=11)

        # B~G列（表头行有文字，数据行为空）
        if is_header:
            header_map = {"B": "去年完成", "C": "今年目标", "D": "行动策略",
                          "E": "可衡量结果", "F": "负责人", "G": "截止日"}
            for col, text in header_map.items():
                set_cell(ws, f"{col}{row_num}", text,
                         fill=YELLOW_FILL, bold=True, size=11)
        else:
            # 数据行：从data字典中找对应维度
            dim_text = template_row.get("A", "")
            field_map = {"B": "去年", "C": "今年", "D": "策略",
                         "E": "可衡量", "F": "负责人", "G": "截止日"}
            for col, key in field_map.items():
                val = data.get(dim_text, {}).get(key, "?") if dim_text else "?"
                row_fill = fill  # 与A列同色板块
                set_cell(ws, f"{col}{row_num}", val,
                         fill=row_fill, bold=False, size=10)

    # 设置列宽
    for col, width in col_widths.items():
        ws.column_dimensions[col].width = width

    # 自动行高
    for row_num in range(2, PARALLEL_ROWS + 1):
        dim_text = PARALLEL_TEMPLATE[row_num].get("A", "")
        strategy_text = data.get(dim_text, {}).get("策略", "?") if dim_text else "?"
        lines = calc_lines(strategy_text, col_widths['D'])
        ws.row_dimensions[row_num].height = max(30, lines * 18 + 10)

    ws.freeze_panes = 'B2'


def create_sandbox_excel(data: dict, output_path: str, template: str = "series"):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "策略沙盘"

    if template == "parallel":
        fill_parallel_sheet(ws, data)
        rows_info = "11行×7列（并联模板）"
    elif template == "custom":
        # 自定义模板：默认用串联模板结构，提示用户上传自己的模板
        fill_series_sheet(ws, data)
        rows_info = "8行×7列（自定义/串联模板）"
    else:
        fill_series_sheet(ws, data)
        rows_info = "8行×7列（串联模板）"

    wb.save(output_path)
    print(f"✅ 策略沙盘已生成（{rows_info}）：{output_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="生成策略沙盘Excel")
    parser.add_argument("--template", default="series",
                        choices=["series", "parallel", "custom"],
                        help="模板类型：series=串联, parallel=并联, custom=自定义")
    parser.add_argument("--data", required=True, help="JSON数据文件路径")
    parser.add_argument("--output", required=True, help="输出Excel路径")
    args = parser.parse_args()

    with open(args.data, 'r', encoding='utf-8') as f:
        data = json.load(f)

    create_sandbox_excel(data, args.output, args.template)
