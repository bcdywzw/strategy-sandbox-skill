#!/usr/bin/env python3
"""
策略沙盘Excel生成脚本
根据收集到的企业信息，生成符合模板格式的策略沙盘.xlsx

用法：
python3 generate_excel.py --data data.json --output 策略沙盘_output.xlsx

data.json 格式：
{
  "成交客户数": { "去年": 100, "今年": 150, "策略": "...", "可衡量": "...", "负责人": "...", "截止日": "2024-12-31" },
  "业务总人力": { ... },
  ...
}
"""

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
import json
import argparse

# 黄色填充
YELLOW_FILL = PatternFill(start_color="FFFFFF00", end_color="FFFFFF00", fill_type="solid")
YELLOW_FILL2 = PatternFill(start_color="FFFFFF00", end_color="FFFFFF00", fill_type="solid")
WHITE_FILL = PatternFill(start_color="FFFFFFFF", end_color="FFFFFFFF", fill_type="solid")

# 标黄固定文本（与模板完全一致）
YELLOW_LABELS = {
    "A1": "目标拆解",
    "D1": "去年完成(R)",
    "E1": "今年目标(O)",
    "F1": "关键结果(KR)",
    "H1": "负责人(O)",
    "I1": "截止日(D)",
    "F2": "行动策略",
    "G2": "可衡量结果",
    "A3": "成交\n客户数",
    "B3": "业务总人力",
    "B6": "人均\n触客数",
    "C6": "老客户",
    "C9": "新客户",
    "B15": "转化率",
    "A21": "平均\n客单价",
    "B21": "客均件数",
    "B24": "件均单价",
    "A27": "心态",
    "B27": "心态",
}

# 白色可变单元格 = 模板行对应的F~I列
# 数据字段映射到Excel行号
FIELD_TO_ROWS = {
    "成交客户数": 3,
    "业务总人力": 3,
    "人均触客数": 6,
    "老客户": 6,
    "新客户": 9,
    "转化率": 15,
    "平均客单价": 21,
    "客均件数": 21,
    "件均单价": 24,
    "心态": 27,
}

def create_sandbox_excel(data: dict, output_path: str):
    """创建策略沙盘Excel"""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "策略沙盘"

    # 写入标黄固定内容
    for cell_ref, text in YELLOW_LABELS.items():
        ws[cell_ref] = text
        ws[cell_ref].fill = YELLOW_FILL
        ws[cell_ref].alignment = Alignment(wrap_text=True, vertical='center', horizontal='center')

    # 写入收集到的数据到白色可变单元格
    # C/D/E列 = 去年/今年数值（如果有的话）
    # F列 = 行动策略
    # G列 = 可衡量结果
    # H列 = 负责人
    # I列 = 截止日

    for field, row_num in FIELD_TO_ROWS.items():
        if field in data:
            item = data[field]
            # 策略
            if "策略" in item:
                ws[f'F{row_num}'] = item.get("策略", "?")
            else:
                ws[f'F{row_num}'] = "?"
            # 可衡量结果
            ws[f'G{row_num}'] = item.get("可衡量", "?")
            # 负责人
            ws[f'H{row_num}'] = item.get("负责人", "?")
            # 截止日
            ws[f'I{row_num}'] = item.get("截止日", "?")

            # 如果有去年/今年数值，写入C/D列
            if "去年" in item:
                ws[f'C{row_num}'] = item["去年"]
            if "今年" in item:
                ws[f'D{row_num}'] = item["今年"]

    # 设置行高
    for row in [3, 6, 9, 15, 21, 24, 27]:
        ws.row_dimensions[row].height = 30

    # 设置列宽
    ws.column_dimensions['A'].width = 10
    ws.column_dimensions['B'].width = 10
    ws.column_dimensions['C'].width = 12
    ws.column_dimensions['D'].width = 12
    ws.column_dimensions['E'].width = 12
    ws.column_dimensions['F'].width = 25
    ws.column_dimensions['G'].width = 25
    ws.column_dimensions['H'].width = 12
    ws.column_dimensions['I'].width = 12

    wb.save(output_path)
    print(f"✅ 策略沙盘已生成：{output_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="生成策略沙盘Excel")
    parser.add_argument("--data", required=True, help="JSON数据文件路径")
    parser.add_argument("--output", required=True, help="输出Excel路径")
    args = parser.parse_args()

    with open(args.data, 'r', encoding='utf-8') as f:
        data = json.load(f)

    create_sandbox_excel(data, args.output)
