#!/usr/bin/env python3
"""
策略沙盘Excel生成脚本 v4.2（合并单元格增强版·修复版）
支持：串联模板(8行) + 并联模板(11行) + 自定义模板

v4.2 修复：
- 修复 is_top_left 逻辑：当无合并时 top_left_set 为空，导致所有格被跳过的严重bug
- 引入 can_write_cell() 函数：只有"非合并格"或"合并区域左上格"才能写入

v4.1 核心功能：
- 读取用户模板时自动检测所有合并单元格
- 保存合并信息（坐标范围 + 左上格值）
- 生成时精确重建合并单元格

用法：
  python3 generate_beautiful_excel.py --template [series|parallel|custom] \\
    --data data.json --output out.xlsx [--template-file path/to/your_template.xlsx]
"""

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl import load_workbook
from copy import copy
import json
import argparse
import os

# ============ 颜色 ============
YELLOW_FILL  = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
WHITE_FILL   = PatternFill(start_color="FFFFFF", end_color="FFFFFF", fill_type="solid")
OLDCLIENT_FILL = PatternFill(start_color="E8EAF6", end_color="E8EAF6", fill_type="solid")
NEWCLIENT_FILL = PatternFill(start_color="E3F2FD", end_color="E3F2FD", fill_type="solid")
PERF_FILL     = PatternFill(start_color="E8F5E9", end_color="E8F5E9", fill_type="solid")

# ============ 边框 ============
def thick_border():
    s = Side(style='medium', color='000000')
    return Border(left=s, right=s, top=s, bottom=s)

# ============ 合并单元格处理 ============

def extract_merge_info(ws):
    """从工作表提取所有合并单元格信息（用于读取模板）"""
    merge_list = []
    for mr in ws.merged_cells.ranges:
        top_cell = ws.cell(mr.min_row, mr.min_col)
        merge_list.append({
            'coord':    mr.coord,
            'min_row':  mr.min_row,
            'max_row':  mr.max_row,
            'min_col':  mr.min_col,
            'max_col':  mr.max_col,
            'value':    top_cell.value if top_cell.value else '',
        })
    return merge_list


def build_merge_lookup(merge_list):
    """
    构建合并单元格查找表：
    - top_left_set : 所有左上格坐标集合 {(row, col)}  — 这些格有值
    - region_map   : (row,col) -> coord  — 快速判断某格属于哪个合并区域
    """
    top_left_set = set()
    region_map   = {}
    for m in merge_list:
        top_left_set.add((m['min_row'], m['min_col']))
        for r in range(m['min_row'], m['max_row'] + 1):
            for c in range(m['min_col'], m['max_col'] + 1):
                region_map[(r, c)] = m['coord']
    return top_left_set, region_map


def can_write_cell(row, col, top_left_set, region_map):
    """
    判断某单元格是否可写入数据。
    
    规则：
    - 若 (row,col) 不在任何合并区域内 → 可写入（普通格）
    - 若 (row,col) 是某个合并区域的左上格 → 可写入（合并标题值）
    - 若 (row,col) 是合并区域中的其他格（非左上）→ 不可写入（被合并遮盖）
    """
    if (row, col) not in region_map:
        # 不在任何合并区域中，可写
        return True
    # 在合并区域中，只有左上格可写
    return (row, col) in top_left_set


# ============ 固定模板定义 ============
SERIES_TEMPLATE = {
    1: {"A": "维度",      "B": "去年完成(R)", "C": "今年目标(O)", "D": "行动策略(KR)", "E": "可衡量结果(KR)", "F": "负责人(O)", "G": "截止日(D)"},
    2: {"A": "总业绩"},
    3: {"A": "业务总人力"},
    4: {"A": "人均触客数"},
    5: {"A": "转化率"},
    6: {"A": "客均件数"},
    7: {"A": "件均单价"},
    8: {"A": "心态"},
}
SERIES_ROWS = 8

PARALLEL_TEMPLATE = {
    1:  {"A": "维度",      "B": "去年完成", "C": "今年目标", "D": "行动策略", "E": "可衡量结果", "F": "负责人", "G": "截止日"},
    2:  {"A": "老客业绩"},
    3:  {"A": "老客户数"},
    4:  {"A": "续签率"},
    5:  {"A": "老客均价"},
    6:  {"A": "新客业绩"},
    7:  {"A": "新客户数"},
    8:  {"A": "转化率"},
    9:  {"A": "新客均价"},
    10: {"A": "人数"},
    11: {"A": "人效"},
}
PARALLEL_ROWS = 11

PARALLEL_FILLS = {
    1: YELLOW_FILL, 2: OLDCLIENT_FILL, 3: OLDCLIENT_FILL,
    4: OLDCLIENT_FILL, 5: OLDCLIENT_FILL, 6: NEWCLIENT_FILL,
    7: NEWCLIENT_FILL, 8: NEWCLIENT_FILL, 9: NEWCLIENT_FILL,
    10: PERF_FILL, 11: PERF_FILL,
}

PARALLEL_COL_WIDTHS = {'A': 12, 'B': 22, 'C': 22, 'D': 55, 'E': 40, 'F': 12, 'G': 12}
SERIES_COL_WIDTHS   = {'A': 12, 'B': 22, 'C': 28, 'D': 55, 'E': 40, 'F': 14, 'G': 14}

# ============ 辅助函数 ============
def text_width(text):
    if not text:
        return 0
    return sum(2 if ord(ch) > 127 else 1 for ch in str(text))

def calc_lines(text, col_width_ch):
    if not text or col_width_ch <= 0:
        return 1
    total = 0
    for line in str(text).split('\n'):
        lw = text_width(line)
        total += max(1, (lw + col_width_ch - 1) // col_width_ch) if lw > 0 else 1
    return max(1, total)

def write_cell(ws, row, col, value, fill, bold=False, size=10,
               top_left_set=None, region_map=None, wrap=True):
    """向单元格写入值和样式（含合并保护）"""
    # 合并保护：检查是否可以写
    if top_left_set is not None and region_map is not None:
        if not can_write_cell(row, col, top_left_set, region_map):
            return  # 合并区域中的非左上格，跳过

    cell = ws.cell(row, col)
    cell.value = value if value is not None else '?'
    cell.fill = fill
    cell.alignment = Alignment(wrap_text=wrap, vertical='center', horizontal='left')
    cell.border = thick_border()
    cell.font = Font(bold=bold, size=size)


def apply_merges(ws, merge_list):
    """
    在所有数据写入完成后，将合并单元格重建到工作表。
    注意：必须在数据全部写入后再调用。
    合并后只有左上格的值可见，其他格的值被遮盖（但保留在内存中）。
    """
    for m in merge_list:
        r1, r2 = m['min_row'], m['max_row']
        c1, c2 = m['min_col'], m['max_col']
        if r1 == r2 and c1 == c2:
            continue  # 单格区域无需合并
        top_cell = ws.cell(r1, c1)
        # 左上格已有值（写数据时已写入），只需执行合并
        ws.merge_cells(m['coord'])


# ============ 串联模板填充 ============
def fill_series_sheet(ws, data, merge_list=None):
    """填充串联模板（8行×7列）"""
    top_left_set, region_map = build_merge_lookup(merge_list or [])
    col_widths = SERIES_COL_WIDTHS

    # 第1行：表头
    ws.row_dimensions[1].height = 35
    for col_letter, text in SERIES_TEMPLATE[1].items():
        col_idx = ord(col_letter) - 64
        write_cell(ws, 1, col_idx, text,
                   fill=YELLOW_FILL, bold=True, size=11,
                   top_left_set=top_left_set, region_map=region_map)

    # 数据行
    field_map = list(SERIES_TEMPLATE[1].items())  # [(A,维度),(B,去年),(C,今年),...]
    for row_num in range(2, SERIES_ROWS + 1):
        dim_text = SERIES_TEMPLATE[row_num].get("A", "")
        row_h = 35

        for col_letter, _ in field_map:
            col_idx = ord(col_letter) - 64
            if col_idx == 1:
                # A列：维度标签
                write_cell(ws, row_num, 1, dim_text,
                           fill=YELLOW_FILL, bold=True, size=11,
                           top_left_set=top_left_set, region_map=region_map)
            else:
                key_map = {2: "去年", 3: "今年", 4: "策略",
                           5: "可衡量", 6: "负责人", 7: "截止日"}
                key = key_map.get(col_idx, "")
                val = data.get(dim_text, {}).get(key, '?') if dim_text else '?'
                fill = WHITE_FILL
                if key == '策略':
                    lines = calc_lines(str(val), col_widths.get(col_letter, 30))
                    row_h = max(40, lines * 18 + 10)
                write_cell(ws, row_num, col_idx, val,
                           fill=fill, bold=False, size=10,
                           top_left_set=top_left_set, region_map=region_map)

        ws.row_dimensions[row_num].height = row_h

    for col, width in col_widths.items():
        ws.column_dimensions[col].width = width

    if merge_list:
        apply_merges(ws, merge_list)
    ws.freeze_panes = 'B2'


# ============ 并联模板填充 ============
def fill_parallel_sheet(ws, data, merge_list=None):
    """填充并联模板（11行×7列）"""
    top_left_set, region_map = build_merge_lookup(merge_list or [])
    col_widths = PARALLEL_COL_WIDTHS

    # 第1行：表头
    ws.row_dimensions[1].height = 35
    for col_letter, text in PARALLEL_TEMPLATE[1].items():
        col_idx = ord(col_letter) - 64
        write_cell(ws, 1, col_idx, text,
                   fill=YELLOW_FILL, bold=True, size=11,
                   top_left_set=top_left_set, region_map=region_map)

    # 数据行
    field_map = list(PARALLEL_TEMPLATE[1].items())
    for row_num in range(2, PARALLEL_ROWS + 1):
        dim_text = PARALLEL_TEMPLATE.get(row_num, {}).get("A", "")
        row_fill = PARALLEL_FILLS.get(row_num, WHITE_FILL)
        row_h = 35

        for col_letter, _ in field_map:
            col_idx = ord(col_letter) - 64
            if col_idx == 1:
                # A列
                write_cell(ws, row_num, 1, dim_text,
                           fill=row_fill, bold=True, size=11,
                           top_left_set=top_left_set, region_map=region_map)
            else:
                key_map = {2: "去年", 3: "今年", 4: "策略",
                           5: "可衡量", 6: "负责人", 7: "截止日"}
                key = key_map.get(col_idx, "")
                val = data.get(dim_text, {}).get(key, '?') if dim_text else '?'
                fill = row_fill
                if key == '策略':
                    lines = calc_lines(str(val), col_widths.get(col_letter, 30))
                    row_h = max(40, lines * 18 + 10)
                write_cell(ws, row_num, col_idx, val,
                           fill=fill, bold=False, size=10,
                           top_left_set=top_left_set, region_map=region_map)

        ws.row_dimensions[row_num].height = row_h

    for col, width in col_widths.items():
        ws.column_dimensions[col].width = width

    if merge_list:
        apply_merges(ws, merge_list)
    ws.freeze_panes = 'B2'


# ============ 主函数 ============
def create_sandbox_excel(data: dict, output_path: str,
                         template: str = "series",
                         user_template_path: str = None):
    """
    生成策略沙盘Excel。
    
    参数：
        data: dict，结构 {"维度名": {"去年":"","今年":"","策略":"","可衡量":"","负责人":"","截止日":""}}
        output_path: str，输出文件路径
        template: str，"series" | "parallel" | "custom"
        user_template_path: str，自定义模板文件路径（可选）
    """
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "策略沙盘"

    # 读取用户模板的合并信息（优先使用）
    merge_list = []
    if user_template_path and os.path.exists(user_template_path):
        try:
            wb_tmpl = load_workbook(user_template_path)
            ws_tmpl = wb_tmpl.active
            merge_list = extract_merge_info(ws_tmpl)
            wb_tmpl.close()
            print(f"  📐 检测到用户模板，已提取 {len(merge_list)} 个合并单元格区域")
        except Exception as e:
            print(f"  ⚠️ 读取用户模板失败，将使用内置模板: {e}")

    # 根据模板类型填充
    if template == "parallel":
        fill_parallel_sheet(ws, data, merge_list)
        rows_info = "11行×7列（并联模板）"
    elif template == "custom":
        fill_series_sheet(ws, data, merge_list)
        rows_info = "自定义模板"
    else:
        fill_series_sheet(ws, data, merge_list)
        rows_info = "8行×7列（串联模板）"

    wb.save(output_path)
    print(f"✅ 策略沙盘已生成（{rows_info}）：{output_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="生成策略沙盘Excel v4.2")
    parser.add_argument("--template", default="series",
                        choices=["series", "parallel", "custom"],
                        help="模板类型：series=串联, parallel=并联, custom=自定义")
    parser.add_argument("--data", required=True, help="JSON数据文件路径")
    parser.add_argument("--output", required=True, help="输出Excel路径")
    parser.add_argument("--template-file", default=None,
                        help="用户自定义模板文件路径（可选）")
    args = parser.parse_args()

    with open(args.data, 'r', encoding='utf-8') as f:
        data = json.load(f)

    create_sandbox_excel(data, args.output, args.template, args.template_file)
