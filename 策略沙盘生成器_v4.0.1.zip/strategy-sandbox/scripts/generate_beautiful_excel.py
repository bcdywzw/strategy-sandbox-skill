#!/usr/bin/env python3
"""
策略沙盘Excel生成脚本 v6.1（v4.0配套版本）
支持：串联模板(8行) + 并联模板(11行) + 任意用户模板（任何xlsx文件）

★ 输出路径强制为桌面 ~/Desktop/ ★

★ 用户模板长什么样就生成什么样，一分一毫都不动 ★

【v5.2 核心原则】：
1. 不拆任何原有合并，不加任何新合并
2. 策略内容按列头类别分门别类填入对应列（每个列独立填自己）
3. 自适应尺寸只调整列宽行高，不动合并结构
4. 策略行识别后，每个策略维度填入对应列，不重复、不合并

用法：
  python3 generate_beautiful_excel.py --template custom \\
    --data data.json --output out.xlsx --template-file 用户模板.xlsx
"""

import openpyxl
from openpyxl.styles import Font, Alignment, Border, Side
from openpyxl import load_workbook
import json, argparse, os, re

def thick_border():
    s = Side(style='medium', color='000000')
    return Border(left=s, right=s, top=s, bottom=s)

def text_width(text):
    if not text: return 0
    return sum(2 if ord(ch) > 127 else 1 for ch in str(text))

def calc_lines(text, col_width_char=30):
    if not text: return 1
    total = 0
    for line in str(text).split('\n'):
        lw = text_width(line)
        total += max(1, (lw + col_width_char - 1) // col_width_char) if lw > 0 else 1
    return max(1, total)

def get_a_value(ws, row):
    v = ws.cell(row, 1).value
    return str(v).replace('\n', '').replace('\r', '').strip() if v else ''

def is_strategy_row(ws, row):
    return '策略' in get_a_value(ws, row)

def is_data_row(ws, row):
    a = get_a_value(ws, row)
    return any(kw in a for kw in ['完成', '目标', '指标', '上月', '本月'])

def clean_strat(raw):
    """逐行去掉中文编号①②③④前缀"""
    if not raw or str(raw) in ('?', 'None'): return None
    lines = str(raw).strip().split('\n')
    result = []
    for line in lines:
        c = re.sub(r'^[①②③④⑤⑥⑦⑧⑨⑩]\s*', '', line.strip())
        if c: result.append(c)
    return '\n'.join(result) if result else None

def make_block(raw):
    """
    将原始策略文本重新整理为清晰的1、2、3、4序号。
    原始数据每条带①②③④或①②③④⑤编号，整理后统一为1、2、3、4…
    每条之间用换行分隔。
    """
    if not raw or str(raw) in ('?', 'None'): return '持续优化运营'
    # 按换行分割，逐条去掉中文编号，重新编号
    lines = str(raw).strip().split('\n')
    result = []
    for i, line in enumerate(lines, 1):
        c = re.sub(r'^[①②③④⑤⑥⑦⑧⑨⑩]\s*', '', line.strip())
        if c: result.append(f"{i}、{c}")
    return '\n'.join(result) if result else '持续优化运营'

def re_number(text):
    """重新给文本编号为1、2、3、4"""
    if not text: return ''
    lines = text.split('\n')
    result = []
    for i, ln in enumerate(lines, 1):
        c = re.sub(r'^[①②③④⑤⑥⑦⑧⑨⑩]\s*', '', ln.strip())
        if c: result.append(f"{i}、{c}")
    return '\n'.join(result)

def write_cell(ws, row, col, value, bold=False, size=10, wrap=True, halign='center', red_bold=False):
    cell = ws.cell(row, col)
    cell.value = value if value is not None else ''
    cell.alignment = Alignment(wrap_text=wrap, vertical='center', horizontal=halign)
    cell.border = thick_border()
    if red_bold:
        cell.font = Font(bold=True, size=size, color='FF0000')
    else:
        cell.font = Font(bold=bold, size=size)


# ============ 固定模板填充（内置串联+并联）============

def fill_fixed_template(ws, data, template_type='series'):
    if template_type == 'parallel':
        tmpl = {1:{"A":"维度","B":"去年完成","C":"今年目标","D":"行动策略","E":"可衡量结果","F":"负责人","G":"截止日"},
                2:{"A":"老客业绩"},3:{"A":"老客总数"},4:{"A":"续签率"},5:{"A":"老客均价"},
                6:{"A":"新客业绩"},7:{"A":"新客总数"},8:{"A":"转化率"},9:{"A":"新客均价"},
                10:{"A":"业务总人数"},11:{"A":"人效"}}
        COL_W = {'A':14,'B':22,'C':22,'D':55,'E':40,'F':14,'G':14}
        rows = 11
    else:
        tmpl = {1:{"A":"维度","B":"去年完成(R)","C":"今年目标(O)","D":"行动策略(KR)","E":"可衡量结果(KR)","F":"负责人(O)","G":"截止日(D)"},
                2:{"A":"总业绩"},3:{"A":"业务总人力"},4:{"A":"人均触客数"},
                5:{"A":"转化率"},6:{"A":"客均件数"},7:{"A":"件均单价"},8:{"A":"心态"}}
        COL_W = {'A':12,'B':22,'C':28,'D':55,'E':40,'F':14,'G':14}
        rows = 8

    ws.row_dimensions[1].height = 35
    for col_letter, text in tmpl[1].items():
        col_idx = ord(col_letter) - 64
        write_cell(ws, 1, col_idx, text, bold=True, size=11)

    highlighted = data.get('重点维度', [])
    for row_num in range(2, rows + 1):
        dim = tmpl[row_num].get("A","")
        is_highlighted = dim in highlighted
        row_h = 35
        for col_letter, _ in tmpl[1].items():
            col_idx = ord(col_letter) - 64
            if col_idx == 1:
                write_cell(ws, row_num, 1, dim, bold=True, size=11, red_bold=is_highlighted)
            else:
                cell_val = ''
                # B/C列数字（col_idx 2=去年，3=今年）
                if col_idx == 2:
                    cell_val = data.get(dim, {}).get('去年', '')
                elif col_idx == 3:
                    cell_val = data.get(dim, {}).get('今年', '')
                # 策略/可衡量/负责人/截止日（col_idx 4-7）
                elif col_idx == 4:
                    cell_val = data.get(dim, {}).get('策略', '')
                    if cell_val:
                        lines = calc_lines(str(cell_val), COL_W.get(col_letter, 30))
                        row_h = max(50, lines * 18 + 15)
                elif col_idx == 5:
                    cell_val = data.get(dim, {}).get('可衡量结果', '')
                elif col_idx == 6:
                    cell_val = data.get(dim, {}).get('负责人', '')
                elif col_idx == 7:
                    cell_val = data.get(dim, {}).get('截止日', '')
                halign = 'left' if col_idx in [4, 5] else 'center'
                write_cell(ws, row_num, col_idx, cell_val,
                           bold=False, size=10, wrap=True, halign=halign,
                           red_bold=is_highlighted and col_idx in [1, 4])
        ws.row_dimensions[row_num].height = row_h

    for col, w in COL_W.items():
        ws.column_dimensions[col].width = w
    ws.freeze_panes = 'B2'


# ============ 用兵沙盘模板（v5.2核心·硬编码列头映射）============

YONGBING_COL_MAP = {
    # 列索引 -> (列头标签, 数据key, 数据subkey_pattern)
    # 板块行（第3行）定义：B:E=老客  F:I=新客  J=人数  K=人效
    # 指标行（第4行）定义：B=业绩  C=客户数  D=续签率  E=均价
    #                   F=业绩  G=客户数  H=转化率  I=均价
    2: {'label': '业绩(B-E老客/F-I新客)', 'data_key': None, 'note': 'B2:E2=E列老客(业绩+客户数+续签率+均价)'},
    3: {'label': '客户数', 'data_key': None},
    4: {'label': '续签率', 'data_key': None},
    5: {'label': '均价', 'data_key': None},
    6: {'label': '业绩', 'data_key': None},
    7: {'label': '客户数', 'data_key': None},
    8: {'label': '转化率', 'data_key': None},
    9: {'label': '均价', 'data_key': None},
    10: {'label': '人数', 'data_key': None},
    11: {'label': '人效', 'data_key': None},
}

def fill_yongbing_template(ws, data):
    """
    【用兵沙盘模板专用填充】

    模板列头（第4行）：
      B=业绩(老客) C=客户数(老客) D=续签率(老客) E=均价(老客)
      F=业绩(新客) G=客户数(新客) H=转化率(新客) I=均价(新客)
      J=人数  K=人效

    策略行（第6、8行）：
      B~E列 = 老客户策略（分别对应：业绩/客户数/续签率/均价的策略）
      F~I列 = 新客户策略（分别对应：业绩/客户数/转化率/均价的策略）
      J列 = 人数策略，K列 = 人效策略

    【核心原则】：每个列独立填自己的内容，不重复、不合并。
    """
    max_row = ws.max_row
    max_col = ws.max_column

    print(f"  📐 用兵沙盘模板：{max_row}行×{max_col}列")
    print(f"  🔒 原有合并（不动）: {[m.coord for m in ws.merged_cells.ranges]}")

    # 识别行类型
    strategy_rows = [r for r in range(1, max_row + 1) if is_strategy_row(ws, r)]
    all_data_rows = [r for r in range(1, max_row + 1) if is_data_row(ws, r)]
    data_rows = [r for r in all_data_rows if r not in strategy_rows]
    print(f"  📋 策略行: {strategy_rows}, 数字行: {data_rows}")

    # 解析数据
    def get(key, subkey=''):
        if subkey:
            return str(data.get(key, {}).get(subkey, '') or '')
        return str(data.get(key, '') or '')

    # 数字行数据（第5行=上月，第7行=本月）
    def fill_data_row(row_num, period):
        fills = {
            2: get('老客业绩', period),    # B=老客业绩
            3: get('老客总数', period),    # C=老客总数
            4: get('续签率', period),      # D=续签率
            5: get('老客均价', period),    # E=老客均价
            6: get('新客业绩', period),    # F=新客业绩
            7: get('新客户数', period),    # G=新客客户数
            8: get('转化率', period),      # H=转化率
            9: get('新客均价', period),   # I=新客均价
            10: get('业务总人数', period) or '根据实际情况填写',
            11: get('人效', period) or '根据实际情况填写',
        }
        for col_idx, val in fills.items():
            write_cell(ws, row_num, col_idx, val, bold=False, size=10, wrap=True, halign='center')

    # 判断数字行的时期（"上月\n完成"=去年，"本月\n目标"=今年）
    for row_num in data_rows:
        a = get_a_value(ws, row_num)
        if '上月' in a or '完成' in a:
            fill_data_row(row_num, '去年')
        elif '本月' in a or '目标' in a:
            fill_data_row(row_num, '今年')

    # 策略行数据（按列头类别分填，每个列用 make_block 整理成1、2、3序号）
    # 每条原始策略带①②③④编号 → make_block 去掉中文编号 → 重新标为1、2、3、4
    # 最终效果：每条策略前有清晰的 1、2、3、4 序号，每条换行显示
    strat_by_col = {
        2:  make_block(get('老客业绩', '策略')),
        3:  make_block(get('老客总数', '策略')),
        4:  make_block(get('续签率', '策略')),
        5:  make_block(get('老客均价', '策略')),
        6:  make_block(get('新客业绩', '策略')),
        7:  make_block(get('新客总数', '策略')),
        8:  make_block(get('转化率', '策略')),
        9:  make_block(get('新客均价', '策略')),
        10: make_block(get('人数', '策略')) or '稳定团队，持续提升人效',
        11: make_block(get('人效', '策略')) or '优化结构，聚焦高价值客户',
    }

    print(f"\n  📝 各列策略内容预览:")
    col_labels = {2:'B=老客业绩', 3:'C=客户数', 4:'D=续签率', 5:'E=均价',
                  6:'F=新客业绩', 7:'G=客户数', 8:'H=转化率', 9:'I=均价', 10:'J=人数', 11:'K=人效'}
    for col_idx, content in strat_by_col.items():
        print(f"    列{chr(64+col_idx)}({col_labels.get(col_idx,'')}): {str(content)[:40] if content else '空'}")

    # 策略行填充（每个列只写自己，不重复）
    for row_num in strategy_rows:
        a = get_a_value(ws, row_num)
        for col_idx, content in strat_by_col.items():
            if content:
                write_cell(ws, row_num, col_idx, content, bold=False, size=10, wrap=True, halign='left')

    # 自适应尺寸（不动任何合并）
    print(f"\n  📏 应用自适应列宽行高...")
    for col_i in range(1, max_col + 1):
        col_l = chr(64 + col_i)
        orig = ws.column_dimensions[col_l].width
        if orig is None or orig < 5: orig = 12
        max_c = max(text_width(str(ws.cell(r, col_i).value or '')) for r in range(1, max_row + 1))
        if max_c > 50:
            new_w = max(orig, min(max_c / 2.0, 40))
        elif max_c > 30:
            new_w = max(orig, min(max_c / 2.0, 30))
        else:
            new_w = max(orig, min(max_c / 2.0, 20))
        ws.column_dimensions[col_l].width = new_w

    for row_num in range(1, max_row + 1):
        orig_h = ws.row_dimensions[row_num].height
        if orig_h is None or orig_h < 10: orig_h = 30
        max_l = 1
        for col_i in range(1, max_col + 1):
            v = ws.cell(row_num, col_i).value
            if v:
                cw = ws.column_dimensions[chr(64 + col_i)].width or 15
                lines = calc_lines(str(v), int(cw))
                max_l = max(max_l, lines)
        if is_strategy_row(ws, row_num):
            new_h = min(max(orig_h, max_l * 15 + 30), 400)
        else:
            new_h = min(max(orig_h, max_l * 15 + 15), 400)
        ws.row_dimensions[row_num].height = new_h

    print(f"  🔒 合并单元格（未动）: {[m.coord for m in ws.merged_cells.ranges]}")
    ws.freeze_panes = 'A5'
    print(f"  ✅ 用兵沙盘模板填充完成")


# ============ 通用自定义模板填充 ============

def fill_generic_custom_template(ws, data):
    """通用自定义模板：读取列头，按类别匹配数据填入"""
    max_row = ws.max_row
    max_col = ws.max_column

    # 建立列头映射（第1行或含"维度"的行）
    header_row = 1
    for row in range(1, max_row + 1):
        if '维度' in get_a_value(ws, row) or '指标' in get_a_value(ws, row):
            header_row = row; break

    # 列头：col_idx -> label（直接从单元格读，合并格读取左上格）
    col_headers = {}
    for col in range(1, max_col + 1):
        v = ws.cell(header_row, col).value
        if v: col_headers[col] = str(v)

    print(f"  📐 通用模板：表头行={header_row}，{max_row}行×{max_col}列")
    print(f"  📊 列头: {col_headers}")

    strategy_rows = [r for r in range(1, max_row + 1) if is_strategy_row(ws, r)]
    all_data_rows = [r for r in range(1, max_row + 1) if is_data_row(ws, r)]
    data_rows = [r for r in all_data_rows if r not in strategy_rows]

    # 数字行填充
    for row_num in data_rows:
        a = get_a_value(ws, row_num)
        is_last = any(kw in a for kw in ['上月', '完成'])
        is_this = any(kw in a for kw in ['本月', '目标'])
        period = '去年' if is_last else ('今年' if is_this else '去年')

        for col_idx in range(2, max_col + 1):
            header = col_headers.get(col_idx, '')
            val = ''
            for dim_key, subkeys in [
                ('老客业绩', ['去年', '今年']), ('新客业绩', ['去年', '今年']),
                ('老客总数', ['去年', '今年']), ('老客成交数', ['去年', '今年']),
                ('新客总数', ['去年', '今年']), ('新客成交数', ['去年', '今年']),
                ('续签率', ['去年', '今年']), ('转化率', ['去年', '今年']),
                ('老客均价', ['去年', '今年']), ('新客均价', ['去年', '今年']),
                ('业务总人数', ['去年', '今年']), ('总业绩', ['去年', '今年']),
            ]:
                if any(kw in header for kw in [dim_key[:2]]):
                    sk = next((s for s in subkeys if s in header), period)
                    val = data.get(dim_key, {}).get(sk, ''); break
            if val:
                write_cell(ws, row_num, col_idx, val, bold=False, size=10, wrap=True, halign='center')

    # 策略行填充（按列头匹配策略key）
    for row_num in strategy_rows:
        for col_idx in range(2, max_col + 1):
            header = col_headers.get(col_idx, '')
            val = ''
            for dim_key in ['老客业绩','新客业绩','老客总数','新客总数',
                            '老客成交数','新客成交数',
                            '续签率','转化率','老客均价','新客均价',
                            '业务总人数','总业绩']:
                if any(kw in header for kw in [dim_key[:2]]):
                    val = data.get(dim_key, {}).get('策略', ''); break
            if not val and '人数' in header:
                val = data.get('人数', {}).get('策略', '') or '稳定团队，持续提升'
            if not val and '人效' in header:
                val = data.get('人效', {}).get('策略', '') or '优化结构，聚焦高价值'

            if val:
                cleaned = re_number(clean_strat(val) or '')
                write_cell(ws, row_num, col_idx, cleaned, bold=False, size=10, wrap=True, halign='left')

    # 自适应尺寸
    for col_i in range(1, max_col + 1):
        col_l = chr(64 + col_i)
        orig = ws.column_dimensions[col_l].width or 12
        max_c = max(text_width(str(ws.cell(r, col_i).value or '')) for r in range(1, max_row + 1))
        new_w = max(orig, min(max_c / 2.0, 40 if max_c > 50 else 30 if max_c > 30 else 20))
        ws.column_dimensions[col_l].width = new_w

    for row_num in range(1, max_row + 1):
        orig_h = ws.row_dimensions[row_num].height or 30
        max_l = max((calc_lines(str(ws.cell(row_num, c).value or ''),
                     int(ws.column_dimensions[chr(64+c)].width or 15))
                     for c in range(1, max_col + 1)), default=1)
        new_h = min(max(orig_h, max_l * 15 + 30), 400)
        ws.row_dimensions[row_num].height = new_h

    print(f"  ✅ 通用自定义模板填充完成")


# ============ 主函数 ============

def create_sandbox_excel(data: dict, output_path: str,
                         template: str = "series",
                         user_template_path: str = None):
    if user_template_path and os.path.exists(user_template_path):
        print(f"  📂 加载用户模板：{user_template_path}")
        wb = load_workbook(user_template_path)
        ws = wb.active
        print(f"  📐 模板尺寸：{ws.max_row}行 × {ws.max_column}列")
        print(f"  🔒 原有合并：{[m.coord for m in ws.merged_cells.ranges]}")

        # 判断是否为用兵沙盘模板（有第4行列头：B=业绩 C=客户数...）
        is_yongbing = False
        row4_labels = [ws.cell(4, c).value for c in range(2, 12)]
        if row4_labels[0] and '业绩' in str(row4_labels[0]):
            is_yongbing = True

        if is_yongbing:
            print(f"  🔍 检测到用兵沙盘模板（列头：B=业绩 C=客户数 D=续签率 E=均价...）")
            fill_yongbing_template(ws, data)
        else:
            fill_generic_custom_template(ws, data)
        rows_info = "自定义模板"
    else:
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "策略沙盘"
        fill_fixed_template(ws, data, template)
        rows_info = f"{'并联' if template=='parallel' else '串联'}模板"

    wb.save(output_path)
    print(f"✅ 策略沙盘已生成（{rows_info}）：{output_path}")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="生成策略沙盘Excel v6.0")
    p.add_argument("--template", default="series", choices=["series","parallel","custom"])
    p.add_argument("--data", required=True, help="JSON数据文件路径")
    p.add_argument("--output", required=True, help="输出Excel路径")
    p.add_argument("--template-file", default=None, help="用户自定义模板")
    a = p.parse_args()
    with open(a.data, 'r', encoding='utf-8') as f:
        data = json.load(f)
    create_sandbox_excel(data, a.output, a.template, a.template_file)
