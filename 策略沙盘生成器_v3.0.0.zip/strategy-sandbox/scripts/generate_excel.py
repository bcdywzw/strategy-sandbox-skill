#!/usr/bin/env python3
"""
策略沙盘Excel生成脚本 v2.0
根据收集到的企业信息，生成符合「策略沙盘模板.xlsx」格式的策略沙盘

用法：
python3 generate_excel.py --data data.json --output 策略沙盘_output.xlsx

data.json 格式：
{
  "总业绩":      { "去年": 1000, "今年": 1500, "策略": "...", "可衡量": "...", "负责人": "...", "截止日": "2024-12-31" },
  "业务总人力":  { "去年": 10, "今年": 15, "策略": "...", "可衡量": "...", "负责人": "...", "截止日": "2024-12-31" },
  ...
}
"""

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
import json
import argparse

# ============ 模板配置（与「策略沙盘模板.xlsx」完全一致）============

# 黄色填充
YELLOW_FILL = PatternFill(start_color="FFFFFF00", end_color="FFFFFF00", fill_type="solid")

# 白色填充
WHITE_FILL = PatternFill(start_color="FFFFFFFF", end_color="FFFFFFFF", fill_type="solid")

# 标黄固定文本（一字不改）
YELLOW_LABELS = {
    "A1": "维度",
    "B1": "去年完成(R)",
    "C1": "今年目标(O)",
    "D1": "行动策略(KR)",
    "E1": "可衡量结果(KR)",
    "F1": "负责人(O)",
    "G1": "截止日(D)",
}

# 数据维度 → Excel行号（维度在A列）
FIELD_TO_ROWS = {
    "总业绩":      2,  # A2
    "业务总人力":  3,  # A3
    "人均触客数":  4,  # A4
    "转化率":      5,  # A5
    "客均件数":    6,  # A6
    "件均单价":    7,  # A7
    "心态":        8,  # A8
}

# 白色可变列 = B ~ G 列（第2~8行）
WHITE_COLS = ["B", "C", "D", "E", "F", "G"]


def set_cell(ws, coord, value, fill=WHITE_FILL, wrap=True, bold=False):
    """设置单元格值和样式"""
    cell = ws[coord]
    cell.value = value if value else "?"
    cell.fill = fill
    cell.alignment = Alignment(wrap_text=wrap, vertical='center', horizontal='left')
    if bold:
        cell.font = Font(bold=True)
    return cell


def create_sandbox_excel(data: dict, output_path: str):
    """创建策略沙盘Excel"""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "策略沙盘"

    # ========== 第1行：表头（黄色固定）==========
    for cell_ref, text in YELLOW_LABELS.items():
        set_cell(ws, cell_ref, text, fill=YELLOW_FILL, bold=True)

    # ========== 第2~8行：数据行 ==========
    for field, row_num in FIELD_TO_ROWS.items():
        # A列：维度名称（黄色固定）
        set_cell(ws, f"A{row_num}", field, fill=YELLOW_FILL, bold=True)

        if field in data:
            item = data[field]

            # B列：去年完成
            if "去年" in item and item["去年"] not in (None, ""):
                set_cell(ws, f"B{row_num}", item["去年"])
            else:
                set_cell(ws, f"B{row_num}", "?")

            # C列：今年目标
            if "今年" in item and item["今年"] not in (None, ""):
                set_cell(ws, f"C{row_num}", item["今年"])
            else:
                set_cell(ws, f"C{row_num}", "?")

            # D列：行动策略
            set_cell(ws, f"D{row_num}", item.get("策略", "?"))

            # E列：可衡量结果
            set_cell(ws, f"E{row_num}", item.get("可衡量", "?"))

            # F列：负责人
            set_cell(ws, f"F{row_num}", item.get("负责人", "?"))

            # G列：截止日
            set_cell(ws, f"G{row_num}", item.get("截止日", "?"))

        else:
            # 字段未收集到，填 ?
            for col in WHITE_COLS:
                set_cell(ws, f"{col}{row_num}", "?")

    # ========== 设置行高 ==========
    ws.row_dimensions[1].height = 30  # 表头行
    for row in range(2, 9):
        ws.row_dimensions[row].height = 30

    # ========== 设置列宽 ==========
    ws.column_dimensions['A'].width = 14   # 维度
    ws.column_dimensions['B'].width = 14   # 去年完成
    ws.column_dimensions['C'].width = 14   # 今年目标
    ws.column_dimensions['D'].width = 30   # 行动策略
    ws.column_dimensions['E'].width = 30   # 可衡量结果
    ws.column_dimensions['F'].width = 12   # 负责人
    ws.column_dimensions['G'].width = 14   # 截止日

    wb.save(output_path)
    print(f"✅ 策略沙盘已生成：{output_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="生成策略沙盘Excel")
    parser.add_argument("--data", required=True, help="JSON数据文件路径")
    parser.add_argument("--output", required=True, help="输出Excel路径")
    args = parser.parse_args()

    with open(args.data, 'r', encoding='utf-8') as f:
        data = json.load(f)

    create_sandbox_excel(data, args.output)
