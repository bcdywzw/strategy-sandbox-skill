#!/usr/bin/env python3
"""
策略沙盘数据处理脚本
将用户提供的原始数据整理为模板所需的维度格式

功能：
1. 从原始数据计算模板所需维度（转化率、件均单价、客均件数等）
2. 将对话收集的半结构化数据整理为标准化格式
3. 输出符合 generate_excel.py 输入格式的 JSON

用法：
python3 process_data.py --input raw_data.json --output structured_data.json
"""

import json
import argparse

def process_data(raw_data: dict) -> dict:
    """
    将原始数据处理为模板维度格式

    raw_data 格式示例：
    {
        "成交客户数": 100,
        "总触客数": 500,
        "业务总人力": 10,
        "总客户数": 300,
        "老客户数": 200,
        "新客户数": 50,
        "总业绩": 5000000,
        "成交件数": 300,
        "..."
    }
    """

    processed = {}

    # 成交客户数 Row 3
    last_year_clients = raw_data.get("成交客户数_去年", "?")
    this_year_clients = raw_data.get("成交客户数_今年", "?")
    processed["成交客户数"] = {
        "去年": last_year_clients,
        "今年": this_year_clients,
        "策略": raw_data.get("成交客户数_策略", "?"),
        "可衡量": raw_data.get("成交客户数_可衡量", "?"),
        "负责人": raw_data.get("成交客户数_负责人", "?"),
        "截止日": raw_data.get("成交客户数_截止日", "?")
    }

    # 业务总人力 Row 3
    processed["业务总人力"] = {
        "去年": raw_data.get("业务总人力_去年", "?"),
        "今年": raw_data.get("业务总人力_今年", "?"),
        "策略": raw_data.get("业务总人力_策略", "?"),
        "可衡量": raw_data.get("业务总人力_可衡量", "?"),
        "负责人": raw_data.get("业务总人力_负责人", "?"),
        "截止日": raw_data.get("业务总人力_截止日", "?")
    }

    # 人均触客数 Row 6
    total_clients_last = raw_data.get("总客户数_去年", "?")
    biz人力_last = raw_data.get("业务总人力_去年", "?")
    if total_clients_last != "?" and biz人力_last not in ("?", 0):
        人均触客数_last = round(total_clients_last / biz人力_last, 2)
    else:
        人均触客数_last = "?"

    total_clients_this = raw_data.get("总客户数_今年", "?")
    biz人力_this = raw_data.get("业务总人力_今年", "?")
    if total_clients_this != "?" and biz人力_this not in ("?", 0):
        人均触客数_this = round(total_clients_this / biz人力_this, 2)
    else:
        人均触客数_this = "?"

    processed["人均触客数"] = {
        "去年": 人均触客数_last,
        "今年": 人均触客数_this,
        "策略": raw_data.get("人均触客数_策略", "?"),
        "可衡量": raw_data.get("人均触客数_可衡量", "?"),
        "负责人": raw_data.get("人均触客数_负责人", "?"),
        "截止日": raw_data.get("人均触客数_截止日", "?")
    }

    # 老客户 Row 6
    processed["老客户"] = {
        "去年": raw_data.get("老客户数_去年", "?"),
        "今年": raw_data.get("老客户数_今年", "?"),
        "策略": raw_data.get("老客户_策略", "?"),
        "可衡量": raw_data.get("老客户_可衡量", "?"),
        "负责人": raw_data.get("老客户_负责人", "?"),
        "截止日": raw_data.get("老客户_截止日", "?")
    }

    # 新客户 Row 9
    processed["新客户"] = {
        "去年": raw_data.get("新客户数_去年", "?"),
        "今年": raw_data.get("新客户数_今年", "?"),
        "策略": raw_data.get("新客户_策略", "?"),
        "可衡量": raw_data.get("新客户_可衡量", "?"),
        "负责人": raw_data.get("新客户_负责人", "?"),
        "截止日": raw_data.get("新客户_截止日", "?")
    }

    # 转化率 Row 15
    if last_year_clients != "?" and raw_data.get("总触客数_去年") not in ("?", 0):
        转化率_last = round(last_year_clients / raw_data["总触客数_去年"] * 100, 2)
    else:
        转化率_last = "?"

    if this_year_clients != "?" and raw_data.get("总触客数_今年") not in ("?", 0):
        转化率_this = round(this_year_clients / raw_data["总触客数_今年"] * 100, 2)
    else:
        转化率_this = "?"

    processed["转化率"] = {
        "去年": 转化率_last,
        "今年": 转化率_this,
        "策略": raw_data.get("转化率_策略", "?"),
        "可衡量": raw_data.get("转化率_可衡量", "?"),
        "负责人": raw_data.get("转化率_负责人", "?"),
        "截止日": raw_data.get("转化率_截止日", "?")
    }

    # 平均客单价 Row 21
    processed["平均客单价"] = {
        "去年": raw_data.get("平均客单价_去年", "?"),
        "今年": raw_data.get("平均客单价_今年", "?"),
        "策略": raw_data.get("平均客单价_策略", "?"),
        "可衡量": raw_data.get("平均客单价_可衡量", "?"),
        "负责人": raw_data.get("平均客单价_负责人", "?"),
        "截止日": raw_data.get("平均客单价_截止日", "?")
    }

    # 客均件数 Row 21
    if this_year_clients not in ("?", 0) and raw_data.get("成交件数_今年") not in ("?", 0):
        客均件数_this = round(raw_data["成交件数_今年"] / this_year_clients, 2)
    else:
        客均件数_this = "?"

    if last_year_clients not in ("?", 0) and raw_data.get("成交件数_去年") not in ("?", 0):
        客均件数_last = round(raw_data["成交件数_去年"] / last_year_clients, 2)
    else:
        客均件数_last = "?"

    processed["客均件数"] = {
        "去年": 客均件数_last,
        "今年": 客均件数_this,
        "策略": raw_data.get("客均件数_策略", "?"),
        "可衡量": raw_data.get("客均件数_可衡量", "?"),
        "负责人": raw_data.get("客均件数_负责人", "?"),
        "截止日": raw_data.get("客均件数_截止日", "?")
    }

    # 件均单价 Row 24
    if raw_data.get("总业绩_去年") not in ("?", 0) and raw_data.get("成交件数_去年") not in ("?", 0):
        件均单价_last = round(raw_data["总业绩_去年"] / raw_data["成交件数_去年"], 2)
    else:
        件均单价_last = "?"

    if raw_data.get("总业绩_今年") not in ("?", 0) and raw_data.get("成交件数_今年") not in ("?", 0):
        件均单价_this = round(raw_data["总业绩_今年"] / raw_data["成交件数_今年"], 2)
    else:
        件均单价_this = "?"

    processed["件均单价"] = {
        "去年": 件均单价_last,
        "今年": 件均单价_this,
        "策略": raw_data.get("件均单价_策略", "?"),
        "可衡量": raw_data.get("件均单价_可衡量", "?"),
        "负责人": raw_data.get("件均单价_负责人", "?"),
        "截止日": raw_data.get("件均单价_截止日", "?")
    }

    # 心态 Row 27
    processed["心态"] = {
        "策略": raw_data.get("心态_策略", "?"),
        "可衡量": raw_data.get("心态_可衡量", "?"),
        "负责人": raw_data.get("心态_负责人", "?"),
        "截止日": raw_data.get("心态_截止日", "?")
    }

    return processed


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="处理策略沙盘原始数据")
    parser.add_argument("--input", required=True, help="原始数据JSON文件路径")
    parser.add_argument("--output", required=True, help="处理后数据输出路径")
    args = parser.parse_args()

    with open(args.input, 'r', encoding='utf-8') as f:
        raw_data = json.load(f)

    processed = process_data(raw_data)

    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(processed, f, ensure_ascii=False, indent=2)

    print(f"✅ 数据处理完成：{args.output}")
