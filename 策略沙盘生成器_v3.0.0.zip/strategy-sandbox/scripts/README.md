# scripts/

本目录存放策略沙盘生成所需的辅助脚本。

## 文件说明

| 文件 | 说明 |
|------|------|
| `generate_excel.py` | 根据结构化数据生成Excel策略沙盘文件 |
| `process_data.py` | 将原始对话数据整理为模板所需的维度格式 |

## 依赖

```bash
pip install openpyxl
```

## 用法示例

```bash
# 第一步：处理原始数据
python3 scripts/process_data.py --input raw_data.json --output structured_data.json

# 第二步：生成Excel
python3 scripts/generate_excel.py --data structured_data.json --output 策略沙盘_output.xlsx
```
